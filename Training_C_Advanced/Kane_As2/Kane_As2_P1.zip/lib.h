#ifndef _LIB_H_
#define _LIB_H_

#include <stdio.h>
#include <stdlib.h>

void Input(int a[], int n);
void Output_Array(int a[], int n);
void Cal_Average(int a[], int n, float *avrg);
void Less_Aveg(int a[], int n, float *avrg, float *L);
void Search(int a[], int n, int num);
void odd_Element(int a[], int n);

#endif